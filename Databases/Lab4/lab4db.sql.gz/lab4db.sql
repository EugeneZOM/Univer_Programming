-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 26 2020 г., 17:54
-- Версия сервера: 10.4.10-MariaDB
-- Версия PHP: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lab4`
--

-- --------------------------------------------------------

--
-- Структура таблицы `books`
--

CREATE TABLE `books` (
  `id` int(7) UNSIGNED NOT NULL,
  `code` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new` tinyint(1) DEFAULT 0,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cost` decimal(5,2) DEFAULT NULL,
  `publishing` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pages` int(5) NOT NULL,
  `format` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT '70x100 / 16',
  `date` date DEFAULT current_timestamp(),
  `circulation` int(7) DEFAULT 5000,
  `theme` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `books`
--

INSERT INTO `books` (`id`, `code`, `new`, `title`, `cost`, `publishing`, `pages`, `format`, `date`, `circulation`, `theme`, `category`) VALUES
(1, '123', 0, 'S0m3 b0ok\'s title', '14.20', 'Publisher name', 400, '70x100 / 16', '2000-02-17', 5000, 'Programming', 'C & C++'),
(2, '5110', 0, 'Unix Guide', '0.00', 'Publish', 300, '70x100 / 16', '2001-05-13', 5000, 'OS', 'Unix'),
(3, '140', 1, 'Unix Guide 2', '24.00', 'Publish', 200, '70x100 / 16', '2020-02-14', NULL, 'OS', 'Unix'),
(4, '4995', 0, 'Kastaneda 12456', '40.00', 'Old Publisher', 320, '70x100 / 16', '2020-02-17', 5000, 'Psychology', 'Dreams'),
(5, '5110', 1, 'Аппликации', '15.00', 'Художественная студия', 200, '70x100 / 16', '2000-07-17', 5000, 'Культура', 'Картины'),
(6, '5110', 1, 'Новая аппликации в народе', '10.80', 'Художественная студия', 120, '70x100 / 16', '2000-02-17', 5000, 'Культура', 'Картины'),
(7, '5110', 0, 'Аппликации в народе 567890', '20.00', 'Художественная студия', 120, '70x100 / 16', NULL, 5000, 'Культура', 'Картины'),
(8, '5110', 1, 'New book', '24.52', 'Publishing house', 250, '70x100 / 60', '2020-01-02', 2000, 'Sometheme', 'Somecategory'),
(9, '5110', 0, 'New book', NULL, 'Publishing house', 250, '70x100 / 16', '2020-03-02', 5000, 'Sometheme', 'Somecategory');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `books`
--
ALTER TABLE `books`
  MODIFY `id` int(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
