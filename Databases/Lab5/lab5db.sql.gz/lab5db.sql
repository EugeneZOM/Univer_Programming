-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 26 2020 г., 20:17
-- Версия сервера: 10.4.10-MariaDB
-- Версия PHP: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lab5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `book`
--

CREATE TABLE `book` (
  `id` int(7) UNSIGNED NOT NULL,
  `category_id` int(7) UNSIGNED NOT NULL,
  `code` varchar(4) NOT NULL,
  `cost` decimal(5,2) NOT NULL,
  `circulation` int(7) DEFAULT 5000,
  `date` date DEFAULT current_timestamp(),
  `format_id` int(7) UNSIGNED DEFAULT NULL,
  `new` tinyint(1) DEFAULT 0,
  `pages` int(5) NOT NULL,
  `publisher_id` int(7) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `theme_id` int(7) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `book`
--

INSERT INTO `book` (`id`, `category_id`, `code`, `cost`, `circulation`, `date`, `format_id`, `new`, `pages`, `publisher_id`, `title`, `theme_id`) VALUES
(1, 1, '5110', '15.51', 5000, '2000-07-24', 1, 0, 400, 1, 'Апаратні засоби мультимедія. відеосистема РС', 1),
(2, 1, '4985', '18.90', 5000, '2000-07-07', 1, 0, 288, 2, 'Освой самостійно модернізацію і ремонт ПК за 24 години, 2-е вид.', 1),
(3, 1, '5141', '37.80', 5000, '2000-09-29', 1, 0, 384, 2, 'Структури даних і алгоритми.', 1),
(4, 1, '5127', '11.58', 5000, '2000-06-15', 1, 1, 256, 3, 'Автоматизація інженерно графічних робіт', 1),
(5, 2, '5110', '15.51', 5000, '2000-07-24', 1, 0, 400, 1, 'Апаратні засоби мультимедія. відеосистема РС', 1),
(6, 2, '5199', '30.07', 5000, '2000-12-02', 1, 0, 368, 4, 'Залізо IBM 2001.', 1),
(7, 3, '3851', '26.00', 5000, '1999-02-04', 2, 1, 480, 5, 'Захист інформації і безпека комп\'ютерних систем', 1),
(8, 4, '3932', '7.65', 5000, '1999-06-09', 3, 0, 144, 6, 'Як перетворити персональний комп\'ютер у вимірювальний комплекс', 1),
(9, 4, '4713', '11.41', 5000, '2000-02-22', 1, 0, 144, 6, 'Plug-ins. Вбудовувані додатки для музичних програм', 1),
(10, 5, '5217', '16.57', 5000, '2000-08-25', 1, 0, 320, 7, 'Windows МЕ. Новітні версії програм', 2),
(11, 5, '4829', '27.25', 5000, '2000-04-28', 1, 0, 320, 8, 'Windows 2000 Professional крок за кроком з ЗD', 2),
(12, 6, '5170', '24.43', 5000, '2000-09-29', 1, 0, 346, 6, 'Linux Російські версії', 2),
(13, 7, '860', '3.50', 5000, '1997-05-05', 4, 0, 395, 1, 'Операційна система UNIX', 2),
(14, 8, '44', '5.00', 5000, '1996-03-20', 5, 0, 352, 5, 'Відповіді на актуальні питання по OS / 2 Warp', 2),
(15, 8, '5176', '12.79', 5000, '2000-10-10', NULL, 0, 306, 9, 'Windows Ме. супутник користувача', 2),
(16, 9, '5462', '29.00', 5000, '2000-12-12', 2, 0, 656, 5, 'Мова програмування С ++. Лекції і вправи', 3),
(17, 9, '4982', '29.00', 5000, '2000-07-12', 2, 0, 432, 5, 'Мова програмування С. Лекції і вправи', 3),
(18, 9, '4687', '17.60', 5000, '2000-02-03', 1, 0, 240, 6, 'Ефективне використання C++. 50 рекомендацій щодо поліпшення ваших програм і проектів', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` int(7) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'підручники'),
(2, 'Апаратні засоби ПК'),
(3, 'Захист і безпека ПК'),
(4, 'інші книги'),
(5, 'Windows 2000'),
(6, 'Linux'),
(7, 'Unix'),
(8, 'Інші операційні системи'),
(9, 'C & C ++');

-- --------------------------------------------------------

--
-- Структура таблицы `format`
--

CREATE TABLE `format` (
  `id` int(7) UNSIGNED NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `format`
--

INSERT INTO `format` (`id`, `value`) VALUES
(1, '70x100 / 16'),
(2, '84x108 / 16'),
(3, '60x88 / 16'),
(4, '84x100 / 16'),
(5, '60x84 / 16');

-- --------------------------------------------------------

--
-- Структура таблицы `publisher`
--

CREATE TABLE `publisher` (
  `id` int(7) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `publisher`
--

INSERT INTO `publisher` (`id`, `name`) VALUES
(1, 'BHV С.-Петербург'),
(2, 'Вільямс'),
(3, 'Пітер'),
(4, 'МікроАрт'),
(5, 'DiaSoft'),
(6, 'ДМК'),
(7, 'Тріумф'),
(8, 'Еком'),
(9, 'Російська редакція');

-- --------------------------------------------------------

--
-- Структура таблицы `theme`
--

CREATE TABLE `theme` (
  `id` int(7) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `theme`
--

INSERT INTO `theme` (`id`, `name`) VALUES
(1, 'Використання ПК в цілому'),
(2, 'Операційні системи'),
(3, 'програмування');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `format_id` (`format_id`),
  ADD KEY `publisher_id` (`publisher_id`),
  ADD KEY `theme_id` (`theme_id`);

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `format`
--
ALTER TABLE `format`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `theme`
--
ALTER TABLE `theme`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `book`
--
ALTER TABLE `book`
  MODIFY `id` int(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `format`
--
ALTER TABLE `format`
  MODIFY `id` int(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `publisher`
--
ALTER TABLE `publisher`
  MODIFY `id` int(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `theme`
--
ALTER TABLE `theme`
  MODIFY `id` int(7) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `book_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `book_ibfk_2` FOREIGN KEY (`format_id`) REFERENCES `format` (`id`),
  ADD CONSTRAINT `book_ibfk_3` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`id`),
  ADD CONSTRAINT `book_ibfk_4` FOREIGN KEY (`theme_id`) REFERENCES `theme` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
